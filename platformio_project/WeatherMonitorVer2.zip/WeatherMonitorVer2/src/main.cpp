// AUTHOR: GUILLERMO PEREZ GUILLEN

#include <Arduino.h>
#include <Notecard.h> 
#include <NotecardPseudoSensor.h> 
#include <Wire.h>
#include "SparkFunCCS811.h"  //CCS811 
#include "DHT20.h" //DHT20

DHT20 DHT; //DHT20

using namespace blues; 

#define CCS811_ADDR 0x5B //Default I2C Address
CCS811 mySensor(CCS811_ADDR);

#define productUID "com.yahoo.guillengap:weather_monitor_version2" 
Notecard notecard; 
NotecardPseudoSensor sensor(notecard); 

void setup()
{
  DHT.begin(); //DHT20
  delay(2500); //DHT20

  Serial.begin(115200);
  Serial.println("CCS811 Basic Example");

  Wire.begin(); //Compilation will fail here if your hardware doesn't support additional Wire ports

  //This begins the CCS811 sensor and prints error status of .beginWithStatus()
  CCS811Core::CCS811_Status_e returnCode = mySensor.beginWithStatus(Wire); //Pass Wire1 into the library
  Serial.print("CCS811 begin exited with: ");
  Serial.println(mySensor.statusString(returnCode));
  
  notecard.begin(); 
  notecard.setDebugOutputStream(Serial); 

  J *req = notecard.newRequest("hub.set"); 
  JAddStringToObject(req, "product", productUID); 
  JAddStringToObject(req, "mode", "continuous"); 
  notecard.sendRequest(req); 
}

void loop()
{
  //Check to see if data is ready with .dataAvailable()
  if (mySensor.dataAvailable())
  {
    //If so, have the sensor read and calculate the results.
    //Get them later
    mySensor.readAlgorithmResults(); //CCS811
    float CO2 = mySensor.getCO2(); //CCS811
    float tVOC = mySensor.getTVOC(); //CCS811

    Serial.print("CO2 = ");
    Serial.print(CO2);
    Serial.println(" ppm");
    Serial.print("tVOC = ");
    Serial.print(tVOC);
    Serial.println(" ppb");

    int status = DHT.read(); //DHT20
    float temperature = DHT.getTemperature(); //DHT20
    float humidity = DHT.getHumidity(); //DHT20

    Serial.print("Temperature = "); //DHT20
    Serial.print(temperature); //DHT20
    Serial.println(" *C"); //DHT20
    Serial.print("Humidity = "); //DHT20
    Serial.print(humidity); //DHT20
    Serial.println(" %"); //DHT20

    J *req = notecard.newRequest("note.add"); 
    if (req != NULL) 
    {
      mySensor.readAlgorithmResults(); //CCS811
      float CO2 = mySensor.getCO2(); //CCS811
      float tVOC = mySensor.getTVOC(); //CCS811

      int status = DHT.read(); //DHT20
      float temperature = DHT.getTemperature(); //DHT20
      float humidity = DHT.getHumidity(); //DHT20      

      JAddStringToObject(req, "file", "sensors.qo"); 
      JAddBoolToObject(req, "sync", true); 
      J *body = JAddObjectToObject(req, "body"); 
      if (body) 
      {
        JAddNumberToObject(body, "temp", temperature); 
        JAddNumberToObject(body, "humidity", humidity);         
        JAddNumberToObject(body, "CO2", CO2); 
        JAddNumberToObject(body, "tVOC", tVOC); 
      }
      notecard.sendRequest(req); 
    }
  }
  delay(5000); //Don't spam the I2C bus
}